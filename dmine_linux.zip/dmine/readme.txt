Please run install.sh to install dmine.
